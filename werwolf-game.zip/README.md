# werewolf-game
Spielleiter APP für Werwölfe vom Düsterwald

v0.01 Rollenauswahl und Zählweise sieht gut aus!
v0.03 Zufällige Rollenzuweisung eingebaut. Rollenauswahl mit DIeb & Spzialrollen angepasst. Oh yes
v0.04 ROllenaktion Armor ist eingebaut